create
    definer = root@localhost function queryChildrenDataSetId2(datasetid int, userid int) returns varchar(4000)
BEGIN

DECLARE sTemp VARCHAR(4000);

DECLARE sTempChd VARCHAR(4000);



SET sTemp = '$';

SET sTempChd = cast(datasetid as char);



WHILE sTempChd is not NULL DO

SET sTemp = CONCAT(sTemp,',',sTempChd);

SELECT group_concat(dataset_id) INTO sTempChd FROM yq_screen where is_delete = 0 and user_id = userid and FIND_IN_SET(old_dataset_id,sTempChd)>0;

END WHILE;

return sTemp;

END;

